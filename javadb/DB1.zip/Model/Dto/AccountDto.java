package Model.Dto;
public class AccountDto{
    private String id ="";
    
    public void SetId(String _id)
    {
        this.id = _id;
    }
    public String GetId()
    {
        return this.id;
    }

}