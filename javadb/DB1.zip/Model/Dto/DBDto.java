package Model.Dto;

public class DBDto {
    
}
