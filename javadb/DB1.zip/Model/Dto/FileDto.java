package Model.Dto;
public class FileDto {
    public final String userSaltListFilePath = "./txtfile/User Salt List.txt";
    public final String saltSaveFilePath = "./txtfile/Salt.txt";
    public final String UserLoginLogPath = "./txtfile/userlog.txt";

    
}
